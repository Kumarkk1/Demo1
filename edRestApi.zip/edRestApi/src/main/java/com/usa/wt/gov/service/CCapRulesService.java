package com.usa.wt.gov.service;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.usa.wt.gov.request.IndvInfoRequest;
import com.usa.wt.gov.responce.PlanInfoResponce;

/**
 * this class for the provides rules & condition for Ccap
 * 
 * @author pavan
 *
 */
public class CCapRulesService implements IRulesService {

	Logger logger = LoggerFactory.getLogger(CCapRulesService.class);

	/**
	 * @return response
	 */
	@Override
	public PlanInfoResponce executeRules(IndvInfoRequest request) {
		logger.debug(" executeRules() method execution started, in CCapRulesService");
		Double income = request.getMontlyIncome();
		Integer kidCount = request.getNoOfKids();
		PlanInfoResponce response = new PlanInfoResponce();
		// set the planName
		response.setPlanName(request.getPlanName());
		// now check the condition
		if (income < 1000 && kidCount > 0) {

			// approve the plane
			response.setPlanStatus(" Congratulations plan Approved..!");
			response.setBenifitAmount(350.00);
			response.setPlanStartDate(new Date());
			response.setPlanEndDate(new Date());
		} else {
			logger.warn("income is more than 1000 or kidCount is not available.. in CCapRulesService plan   ");
			response.setPlanStatus(" Sorry..! plan Denied");
			response.setDeniedReason("due to more than 1000 salary or lack of kids...");
		}
		logger.debug(" executeRules() method execution started, in CCapRulesService");
		logger.info("executeRules() method execution completed..");
		return response;
	}

}
