package com.usa.wt.gov.exception;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;

@Controller
@ControllerAdvice
public class EdException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6551454275745355081L;

}
