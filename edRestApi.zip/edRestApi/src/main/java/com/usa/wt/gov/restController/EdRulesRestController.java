package com.usa.wt.gov.restController;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.usa.wt.gov.request.IndvInfoRequest;
import com.usa.wt.gov.responce.PlanInfoResponce;
import com.usa.wt.gov.service.EdRulesService;

/**
 * this class the controller class
 * 
 * @author pavan
 *
 */
@RestController
public class EdRulesRestController {

	Logger logger = LoggerFactory.getLogger(EdRulesRestController.class);

	@Autowired
	private EdRulesService edRulesService;

	@PostMapping(value = "/edRulesEligibility", consumes = { "application/xml", "application/json" }, produces = {
			"application/xml", "application/json" })
	public @ResponseBody PlanInfoResponce checkEligibility(@RequestBody IndvInfoRequest request) {
		logger.debug("checkEligibility() method execution started...");
		// call the service class method
		PlanInfoResponce response = edRulesService.findEligibility(request);
		logger.debug("checkEligibility() method execution ended..");
		logger.info("checkEligibility() method execution completed successfully..");
		return response;
	}

}