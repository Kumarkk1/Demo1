package com.usa.wt.gov.responce;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;

/**
 * this class ton for the response make this class as the binding class
 * 
 * @author pavan
 *
 */
@Data
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class PlanInfoResponce {

	private Integer planId;
	private String planName;
	private String planStatus;
	private Date planStartDate;
	private Date planEndDate;
	private Double benifitAmount;
	private String deniedReason;

}
