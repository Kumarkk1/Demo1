package com.usa.wt.gov.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;

/**
 * this class to send the data as input make this class as binding class
 * 
 * @author pavan
 *
 */

@Data
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class IndvInfoRequest {
	private Integer indvId;
	private Long ssn;
	private String firstName;
	private String lastName;
	private String planName;
	private Integer age;
	private String gender;
	private Double montlyIncome;
	private String maritalStatus;
	private Integer noOfKids;
	private Boolean nationality;
	private Integer noOfResource;

}
