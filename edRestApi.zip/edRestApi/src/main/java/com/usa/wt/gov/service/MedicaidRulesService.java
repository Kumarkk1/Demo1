package com.usa.wt.gov.service;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.usa.wt.gov.request.IndvInfoRequest;
import com.usa.wt.gov.responce.PlanInfoResponce;

/**
 * this class provides the rules and conditions for the medicade
 * 
 * @author pavan
 *
 */
public class MedicaidRulesService implements IRulesService {

	Logger logger = LoggerFactory.getLogger(MedicaidRulesService.class);

	/**
	 * @return response
	 */
	@Override
	public PlanInfoResponce executeRules(IndvInfoRequest request) {
		logger.debug("executeRules() method execution started, in MedicadeRulesService");
		Integer noOfResource = request.getNoOfResource();
		Double income = request.getMontlyIncome();
		PlanInfoResponce response = new PlanInfoResponce();
		// set the planName
		response.setPlanName(request.getPlanName());
		if (noOfResource <= 1 && income < 10000) {
			// approve
			response.setPlanStatus("Congratulations plan Appropved...!");
			response.setBenifitAmount(5000.00);
			response.setPlanStartDate(new Date());
			response.setPlanEndDate(new Date());

		} else {
			// denied
			logger.warn(" Resorcess must be one and income should be less than 10000  in  MedicadeRulesService");
			response.setPlanStatus("sorry plan denied...!");
			response.setDeniedReason("due to more income or more resources ");
		}
		logger.debug("executeRules() method execution ended, in MedicadeRulesService");
		logger.info("executeRules() method execution completed, in MedicadeRulesService");
		return response;
	}

}
