package com.usa.wt.gov.service;

import java.util.Date;

import org.apache.catalina.deploy.NamingResourcesImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.usa.wt.gov.request.IndvInfoRequest;
import com.usa.wt.gov.responce.PlanInfoResponce;

/**
 * this class provides the rules & conditions for the Qhp
 * 
 * @author pavan
 * 
 */
public class QhpRulesService implements IRulesService {

	Logger logger = LoggerFactory.getLogger(QhpRulesService.class);

	/**
	 * this method or for the QHP rules and conditions
	 * 
	 * @return response
	 */
	@Override
	public PlanInfoResponce executeRules(IndvInfoRequest request) {
		logger.debug("executeRules() method started execution , in QhpRulesService");
		Boolean flag = request.getNationality();
		PlanInfoResponce response = new PlanInfoResponce();
		// set the planeName
		response.setPlanName(request.getPlanName());
		// conditions
		if (flag == false) {
			// denied
			logger.warn(" without USA nationality is not allowed in QhpRulesService  ");
			response.setPlanStatus("Sorry.. ! plan denied");
			response.setDeniedReason("Nationality must be USA citizen");
		} else {
			response.setPlanStatus(" Congratulations plan Approved..!");
			response.setBenifitAmount(5000.00);
			response.setPlanStartDate(new Date());
			response.setPlanEndDate(new Date());
		}
		logger.debug("executeRules() method ended execution , in QhpRulesService");
		logger.info("executeRules() method completed execution , in QhpRulesService");
		return response;
	}

}
