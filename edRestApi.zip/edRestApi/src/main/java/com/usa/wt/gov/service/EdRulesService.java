package com.usa.wt.gov.service;

import com.usa.wt.gov.request.IndvInfoRequest;
import com.usa.wt.gov.responce.PlanInfoResponce;

public interface EdRulesService {
	public PlanInfoResponce findEligibility(IndvInfoRequest request);

}
