package com.usa.wt.gov.service;

import java.lang.reflect.Method;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.usa.wt.gov.request.IndvInfoRequest;
import com.usa.wt.gov.responce.PlanInfoResponce;

/**
 * this is the service class for the b.Logic to load the class and get the
 * nethod dynamically at runtime
 * 
 * @author pavan
 *
 */
@Service
public class EdRulesServiceImpl implements EdRulesService {

	Logger logger = LoggerFactory.getLogger(EdRulesServiceImpl.class);

	/**
	 * @return response
	 */

	@Override
	public PlanInfoResponce findEligibility(IndvInfoRequest request) {
		logger.debug("findEligibility() method execution started...");
		// set the planName
		String planName = request.getPlanName();
		PlanInfoResponce response = new PlanInfoResponce();
		try {
			// load the class
			Class clz = Class.forName("com.usa.wt.gov.service." + planName + "RulesService");
			// crate the object
			Object object = clz.newInstance();
			// load the method
			Method method = clz.getDeclaredMethod("executeRules", IndvInfoRequest.class);
			// invoke the method
			Object returnVal = method.invoke(object, request);
			// type cast with the response
			response = (PlanInfoResponce) returnVal;
			logger.debug("findEligibility() method execution method ended..");
			logger.info("findEligibility() method execution completed");
		} // try
		catch (Exception e) {
			logger.error("Exception rised in findEligibility() method ");
			e.printStackTrace();
		} // catch

		return response;
	}// method

}// class
