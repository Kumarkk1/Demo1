package com.usa.wt.gov.service;

import com.usa.wt.gov.request.IndvInfoRequest;
import com.usa.wt.gov.responce.PlanInfoResponce;

public interface IRulesService {

	public PlanInfoResponce executeRules(IndvInfoRequest request);

}
