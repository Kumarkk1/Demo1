package com.usa.wt.gov.service;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.usa.wt.gov.request.IndvInfoRequest;
import com.usa.wt.gov.responce.PlanInfoResponce;

/**
 * this class provides the rules & conditions for medicare
 * 
 * @author pavan
 *
 */
public class MedicareRulesService implements IRulesService {

	Logger logger = LoggerFactory.getLogger(MedicareRulesService.class);

	/**
	 * @return response
	 */
	@Override
	public PlanInfoResponce executeRules(IndvInfoRequest request) {
		logger.debug("executeRules() method execution started, in MedicareRulesService");
		Integer age = request.getAge();
		PlanInfoResponce response = new PlanInfoResponce();
		// set the planName
		response.setPlanName(request.getPlanName());
		// condition
		if (age > 65) {
			// approve
			response.setPlanStatus("Congratulations plan Approved...!");
			response.setBenifitAmount(5000.00);
			response.setPlanStartDate(new Date());
			response.setPlanEndDate(new Date());
		} else {
			// denied
			logger.warn("Age must be more than 65 year old ");
			response.setPlanStatus("sorry  Plan Denied..!");
			response.setDeniedReason("due to less age ");
		}
		logger.debug("executeRules() method execution ended, in MedicareRulesService");
		logger.info("executeRules() method execution stompleted , in MedicareRulesService");
		return response;
	}

}
