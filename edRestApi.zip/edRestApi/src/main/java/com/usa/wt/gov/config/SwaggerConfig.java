package com.usa.wt.gov.config;

import java.util.Collections;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * this class for the providing the swagger document
 * 
 * @author pavan
 *
 */
@Configuration
@EnableSwagger2
public class SwaggerConfig {

	@Bean
	public Docket edRestApi() {
		return new Docket(DocumentationType.SWAGGER_2).select()
				.apis(RequestHandlerSelectors.basePackage("com.usa.wt.gov.restController"))
				.paths(PathSelectors.any())
				.build().apiInfo(apiInfo());
	}

	private ApiInfo apiInfo() {
		return new ApiInfo("My edRest API", " some custome description of Rest Api", " version 2.0.0",
				" Terms of service",
				new springfox.documentation.service.Contact("pavan", "www.pavankumar.com", "pavan678k@gmail.com"),
				"License of API", " API license URL", Collections.emptyList());
	}
}
